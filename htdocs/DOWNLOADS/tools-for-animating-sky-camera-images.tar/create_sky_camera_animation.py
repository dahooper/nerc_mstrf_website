#! /usr/bin/python
#
# Python program to animate NERC MST Radar Facility sky-camera images
#
# Written by David Hooper, Rutherford Appleton Laboratory
# This version released on 2007-11-28
#
# See http://mst.nerc.ac.uk for full details
#
# Usage:
#
# The Python program will animate all jpg image files that it finds in
# a given source directory, source_dir_name, (e.g.
# /home/mst/sky-camera-images on a Linux/Unix machine or
# d:\sky-camera-images on a Windows machine). Therefore ensure that
# all files in the source directory are for contiguous time
# steps. Create a separate directory for each group of images to be
# animated. The program will ignore all files which do not conform to
# the standard (jpg) sky-camera image naming convention - including
# the tar files.
#
# The Python program will generate the following files in the source
# directory:
#
#   animation.html
#   logo_mst.png
#   logo_nerc.png
#   page-style.css
#
# Direct your web-browser to the animation.html file and click on PLAY.
#
# Irrespective of the platform on which the Python code is being run,
# it is invoked with the following general syntax:
#
#  python program_file_path source_dir_name
#
# where program_file_path is the (absolute or relative) path name of
# the create_sky_camera_animation.py file, and source_dir_name is the
# (absolute or relative) name of the source image directory. The three
# examples below demonstrate how to the run the program given the
# following scenarios:
#
# a) the Python program is run from an arbitrary directory, using absolute
#    paths for both program_file_path and source_dir_name
# b) the Python program is run from its own directory and using a relative
#    path for source_dir_name
# c) the Python program is run from source_dir_name and using a relative path
#    for program_file_path. Note, in this case, the final '.' in the commands,
#    which denotes the current directory location.
#
# On a Linux/Unix machine, assuming that the Python program is stored
# in a directory /home/mst/python-programs and that the sky-camera
# image files are stored in a directory /home/mst/sky-camera-images,
# enter:
#
# a) python /home/mst/python-programs/create_sky_camera_animation.py /home/mst/sky-camera-images
# b) python create_sky_camera_animation.py ../sky-camera-images 
# c) python ../python-programs/create_sky_camera_animation.py . 
#
# On a Windows machine you will need to open a Command Prompt window,
# through Start - Programs - Accessories. Assuming that the Python
# program is stored in a directory d:\python-programs and that the
# sky-camera image files are stored in a directory
# d:\sky-camera-images, enter:
#
# a) python d:\python-programs\create_sky_camera_animation.py d:\sky-camera-images 
# b) python create_sky_camera_animation.py ..\sky-camera-images 
# c) python ..\python-programs\create_sky_camera_animation.py . 
#
####################################################################
#
import os, re, sys, tarfile
#
####################################################################
#
# Function to determine which sky-camera images are available in the
# source directory. It ignores any files which do not conform to the
# file naming convention of "sky-camera_capel-dewi_YYYYMMDD_HHMM.jpg"
#
def determine_image_files_available(module_details):
    print "Checking for available sky-camera images"
    module_details["image_file_name_list"] = []
    file_name_list = os.listdir(module_details["source_dir_name"])
    file_name_list.sort()
    for file_name in file_name_list:
        if module_details["image_file_name_re"].match(file_name):
            module_details["image_file_name_list"].append(file_name)
        else:
            print "  Ignoring file: %s" % file_name
#
    module_details["number_of_image_files_available"] = len(
        module_details["image_file_name_list"])
#
    print "  %i sky-camera images available" % module_details[
        "number_of_image_files_available"]
#
#########################################################################
#
# Function to extract auxilliary files from 
#
#   create_sky_camera_animation_attachments.tar
#
# (which must be located in the same directory as this script) into the
# image source directory. It also reads in (to the module_details) the 
# contents of the html file template
#
def extract_auxilliary_files_from_tar_file(module_details):
    current_dir_name = os.path.dirname(__file__)
    tar_file_name = "create_sky_camera_animation_attachments.tar"
    tar_file_path = os.path.join(current_dir_name,tar_file_name)
    tar_file = tarfile.TarFile(tar_file_path,"r")
#
    auxilliary_file_names_to_extract = ["logo_mst.png", 
                                        "logo_nerc.png", 
                                        "page-style.css"]
    for auxilliary_file_name in auxilliary_file_names_to_extract:
        tar_file.extract(auxilliary_file_name,
                         module_details["source_dir_name"])
#        
    auxilliary_file_name = "template.html"
    auxilliary_file = tar_file.extractfile(auxilliary_file_name)
    module_details["html_file_template"] = auxilliary_file.readlines()
#
    tar_file.close()
#
##########################################################################
#
# Function which creates the Javascript html file by substituting
# specific details into the template.
#
def create_html_file(module_details):
    substitution = {}
    substitution["animation_delay"] = "%i" % module_details["animation_delay"]
    substitution["first_image_file_name"] = module_details[
        "image_file_name_list"][0]
    substitution["last_image_number"] = "%i" % (
        module_details["number_of_image_files_available"] - 1)
#
    substitution["image_file_name_list"] = ""
    for image_file_name in module_details["image_file_name_list"]:
        substitution["image_file_name_list"] += '"' + image_file_name + '"'
        if image_file_name == module_details["image_file_name_list"][-1]:
            substitution["image_file_name_list"] += "\n"
        else:
            substitution["image_file_name_list"] += ",\n"   
#
    module_details["html_file_path"] = os.path.join(
        module_details["source_dir_name"],
        module_details["html_file_name"])

    html_file = file(module_details["html_file_path"],"w")
    for html_line in module_details["html_file_template"]:
        not_all_substitutions_have_been_found = True
        while not_all_substitutions_have_been_found:
            beginning_of_substitution = html_line.find("\\sub")
            if beginning_of_substitution == -1:
                not_all_substitutions_have_been_found = False
            else:
                end_of_substitution = html_line.find(
                    "\\",beginning_of_substitution+1)
                substitution_key = html_line[
                    beginning_of_substitution+5:
                    end_of_substitution]
                html_line = html_line[
                    0:beginning_of_substitution] + substitution[
                    substitution_key] + html_line[
                    end_of_substitution+1:]

        html_file.write(html_line)

    html_file.close()
#
#########################################################################
#
# Main script begins here
#
if len(sys.argv) > 2:
    print "ERROR: too many input arguments"
    print "  Usage: ./create_sky_camera_animation.py source_dir_name"
else:
    if len(sys.argv) == 1:
        print "Please input name of directory containing sky-camera images to animate::"
        sys.stdout.write(">> ")
        source_dir_name = sys.stdin.readline()[:-1]
    else:
        source_dir_name = sys.argv[1]
    
    if not(os.path.isdir(source_dir_name)):
        print "ERROR: %s is an invalid source directory" % source_dir_name
    else:
        module_details = {"source_dir_name": source_dir_name,
                          "image_file_name_re": re.compile(
                "sky-camera_capel-dewi_\d{8}_\d{4}.jpg"),
                          "html_file_name": "animation.html",
                          "animation_delay": 200}
        determine_image_files_available(module_details)
        if module_details["number_of_image_files_available"] == 0:
            print "WARNING: no animation file created"
        else:
            extract_auxilliary_files_from_tar_file(module_details)
            create_html_file(module_details)
            print "Animation file path: %s" % module_details[
                "html_file_path"]
